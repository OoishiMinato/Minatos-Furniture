
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.minatosfurniture.item.WatarMelonShavedItem;
import net.mcreator.minatosfurniture.item.ShavedIceItem;
import net.mcreator.minatosfurniture.item.RefrigeratorItem;
import net.mcreator.minatosfurniture.item.HotSpringItem;
import net.mcreator.minatosfurniture.item.GearItem;
import net.mcreator.minatosfurniture.item.FuelItem;
import net.mcreator.minatosfurniture.item.CutCookedRabbitItem;
import net.mcreator.minatosfurniture.item.CutCookedPorkchopItem;
import net.mcreator.minatosfurniture.item.CutCookedMuttonItem;
import net.mcreator.minatosfurniture.item.CutCookedChickenItem;
import net.mcreator.minatosfurniture.item.CutCookedBeefItem;
import net.mcreator.minatosfurniture.item.BathItem;
import net.mcreator.minatosfurniture.MinatoFurnitureMod;

public class MinatoFurnitureModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MinatoFurnitureMod.MODID);
	public static final DeferredHolder<Item, Item> OAK_CHAIR = block(MinatoFurnitureModBlocks.OAK_CHAIR);
	public static final DeferredHolder<Item, Item> SPRUCE_CHAIR = block(MinatoFurnitureModBlocks.SPRUCE_CHAIR);
	public static final DeferredHolder<Item, Item> BIRCH_CHAIR = block(MinatoFurnitureModBlocks.BIRCH_CHAIR);
	public static final DeferredHolder<Item, Item> JUNGLE_CHAIR = block(MinatoFurnitureModBlocks.JUNGLE_CHAIR);
	public static final DeferredHolder<Item, Item> ACACIA_CHAIR = block(MinatoFurnitureModBlocks.ACACIA_CHAIR);
	public static final DeferredHolder<Item, Item> DARK_OAK_CHAIR = block(MinatoFurnitureModBlocks.DARK_OAK_CHAIR);
	public static final DeferredHolder<Item, Item> SMOOTH_STONE_CHAIR = block(MinatoFurnitureModBlocks.SMOOTH_STONE_CHAIR);
	public static final DeferredHolder<Item, Item> POLISHED_GRANITE_CHAIR = block(MinatoFurnitureModBlocks.POLISHED_GRANITE_CHAIR);
	public static final DeferredHolder<Item, Item> POLISHED_DIORITE_CHAIR = block(MinatoFurnitureModBlocks.POLISHED_DIORITE_CHAIR);
	public static final DeferredHolder<Item, Item> POLISHED_ANDESITE_CHAIR = block(MinatoFurnitureModBlocks.POLISHED_ANDESITE_CHAIR);
	public static final DeferredHolder<Item, Item> BATH_1 = block(MinatoFurnitureModBlocks.BATH_1);
	public static final DeferredHolder<Item, Item> BATH_2 = block(MinatoFurnitureModBlocks.BATH_2);
	public static final DeferredHolder<Item, Item> BATH = REGISTRY.register("bath", BathItem::new);
	public static final DeferredHolder<Item, Item> BATH_3 = block(MinatoFurnitureModBlocks.BATH_3);
	public static final DeferredHolder<Item, Item> OAK_TABLE = block(MinatoFurnitureModBlocks.OAK_TABLE);
	public static final DeferredHolder<Item, Item> SPRUCE_TABLE = block(MinatoFurnitureModBlocks.SPRUCE_TABLE);
	public static final DeferredHolder<Item, Item> BIRCH_TABLE = block(MinatoFurnitureModBlocks.BIRCH_TABLE);
	public static final DeferredHolder<Item, Item> JUNGLE_TABLE = block(MinatoFurnitureModBlocks.JUNGLE_TABLE);
	public static final DeferredHolder<Item, Item> ACACIA_TABLE = block(MinatoFurnitureModBlocks.ACACIA_TABLE);
	public static final DeferredHolder<Item, Item> DARK_OAK_TABLE = block(MinatoFurnitureModBlocks.DARK_OAK_TABLE);
	public static final DeferredHolder<Item, Item> SMOOTH_STONE_TABLE = block(MinatoFurnitureModBlocks.SMOOTH_STONE_TABLE);
	public static final DeferredHolder<Item, Item> POLISHED_GRANITE_TABLE = block(MinatoFurnitureModBlocks.POLISHED_GRANITE_TABLE);
	public static final DeferredHolder<Item, Item> POLISHED_DIORITE_TABLE = block(MinatoFurnitureModBlocks.POLISHED_DIORITE_TABLE);
	public static final DeferredHolder<Item, Item> POLISHED_ANDESITE_TABLE = block(MinatoFurnitureModBlocks.POLISHED_ANDESITE_TABLE);
	public static final DeferredHolder<Item, Item> REFRIGERATOR_1 = block(MinatoFurnitureModBlocks.REFRIGERATOR_1);
	public static final DeferredHolder<Item, Item> REFRIGERATOR_2 = block(MinatoFurnitureModBlocks.REFRIGERATOR_2);
	public static final DeferredHolder<Item, Item> REFRIGERATOR = REGISTRY.register("refrigerator", RefrigeratorItem::new);
	public static final DeferredHolder<Item, Item> INGREDIENTS_CUTTER = block(MinatoFurnitureModBlocks.INGREDIENTS_CUTTER);
	public static final DeferredHolder<Item, Item> CUT_COOKED_BEEF = REGISTRY.register("cut_cooked_beef", CutCookedBeefItem::new);
	public static final DeferredHolder<Item, Item> CUT_COOKED_PORKCHOP = REGISTRY.register("cut_cooked_porkchop", CutCookedPorkchopItem::new);
	public static final DeferredHolder<Item, Item> CUT_COOKED_CHICKEN = REGISTRY.register("cut_cooked_chicken", CutCookedChickenItem::new);
	public static final DeferredHolder<Item, Item> GEAR = REGISTRY.register("gear", GearItem::new);
	public static final DeferredHolder<Item, Item> CUT_COOKED_MUTTON = REGISTRY.register("cut_cooked_mutton", CutCookedMuttonItem::new);
	public static final DeferredHolder<Item, Item> HOT_SPRING_BUCKET = REGISTRY.register("hot_spring_bucket", HotSpringItem::new);
	public static final DeferredHolder<Item, Item> SHOWER_HEAD = block(MinatoFurnitureModBlocks.SHOWER_HEAD);
	public static final DeferredHolder<Item, Item> SHOWER_HEAD_ON = block(MinatoFurnitureModBlocks.SHOWER_HEAD_ON);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_1 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_1);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_2 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_2);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_3 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_3);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_4 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_4);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_5 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_5);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_6 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_6);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_7 = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_7);
	public static final DeferredHolder<Item, Item> SHAVED_ICE_MACHINE_IN_ICE = block(MinatoFurnitureModBlocks.SHAVED_ICE_MACHINE_IN_ICE);
	public static final DeferredHolder<Item, Item> SHAVED_ICE = REGISTRY.register("shaved_ice", ShavedIceItem::new);
	public static final DeferredHolder<Item, Item> WATER_MELON_SHAVED = REGISTRY.register("water_melon_shaved", WatarMelonShavedItem::new);
	public static final DeferredHolder<Item, Item> TV = block(MinatoFurnitureModBlocks.TV);
	public static final DeferredHolder<Item, Item> TV_ON = block(MinatoFurnitureModBlocks.TV_ON);
	public static final DeferredHolder<Item, Item> FAN_BLOCK = block(MinatoFurnitureModBlocks.FAN_BLOCK);
	public static final DeferredHolder<Item, Item> FUEL = REGISTRY.register("fuel", FuelItem::new);
	public static final DeferredHolder<Item, Item> HIGH_HEAT_OVEN = block(MinatoFurnitureModBlocks.HIGH_HEAT_OVEN);
	public static final DeferredHolder<Item, Item> CUT_COOKED_RABBIT = REGISTRY.register("cut_cooked_rabbit", CutCookedRabbitItem::new);
	public static final DeferredHolder<Item, Item> TOILET_OPEN = block(MinatoFurnitureModBlocks.TOILET_OPEN);
	public static final DeferredHolder<Item, Item> TOILET = block(MinatoFurnitureModBlocks.TOILET);
	public static final DeferredHolder<Item, Item> OAK_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.OAK_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> SPRUCE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.SPRUCE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> BIRCH_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.BIRCH_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> MANGROVE_CHAIR = block(MinatoFurnitureModBlocks.MANGROVE_CHAIR);
	public static final DeferredHolder<Item, Item> MANGROVE_TABLE = block(MinatoFurnitureModBlocks.MANGROVE_TABLE);
	public static final DeferredHolder<Item, Item> CHERRY_CHAIR = block(MinatoFurnitureModBlocks.CHERRY_CHAIR);
	public static final DeferredHolder<Item, Item> CHERRY_TABLE = block(MinatoFurnitureModBlocks.CHERRY_TABLE);
	public static final DeferredHolder<Item, Item> JUNGLE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.JUNGLE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> ACACIA_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.ACACIA_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> DARK_OAK_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.DARK_OAK_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> MANGROVE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.MANGROVE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> CHERRY_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.CHERRY_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> SMOOTH_STONE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.SMOOTH_STONE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> POLISHED_GRANITE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.POLISHED_GRANITE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> POLISHED_DIORITE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.POLISHED_DIORITE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> POLISHED_ANDESITE_VERTICAL_BOOKSHELF = block(MinatoFurnitureModBlocks.POLISHED_ANDESITE_VERTICAL_BOOKSHELF);
	public static final DeferredHolder<Item, Item> CONNECTED_OAK_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_OAK_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_SPRUCE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_SPRUCE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_BIRCH_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_BIRCH_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_JUNGLE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_JUNGLE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_ACACIA_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_ACACIA_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_DARK_OAK_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_DARK_OAK_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_SMOOTH_STONE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_SMOOTH_STONE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_POLISHED_GRANITE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_POLISHED_GRANITE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_POLISHED_DIORITE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_POLISHED_DIORITE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_POLISHED_ANDESITE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_POLISHED_ANDESITE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_MANGROVE_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_MANGROVE_TABLE);
	public static final DeferredHolder<Item, Item> CONNECTED_CHERRY_TABLE = block(MinatoFurnitureModBlocks.CONNECTED_CHERRY_TABLE);
	public static final DeferredHolder<Item, Item> OAK_BELL = block(MinatoFurnitureModBlocks.OAK_BELL);
	public static final DeferredHolder<Item, Item> SPRUCE_BELL = block(MinatoFurnitureModBlocks.SPRUCE_BELL);
	public static final DeferredHolder<Item, Item> BIRCH_BELL = block(MinatoFurnitureModBlocks.BIRCH_BELL);
	public static final DeferredHolder<Item, Item> JUNGLE_BELL = block(MinatoFurnitureModBlocks.JUNGLE_BELL);
	public static final DeferredHolder<Item, Item> ACACIA_BELL = block(MinatoFurnitureModBlocks.ACACIA_BELL);
	public static final DeferredHolder<Item, Item> DARK_OAK_BELL = block(MinatoFurnitureModBlocks.DARK_OAK_BELL);
	public static final DeferredHolder<Item, Item> SMOOTH_STONE_BELL = block(MinatoFurnitureModBlocks.SMOOTH_STONE_BELL);
	public static final DeferredHolder<Item, Item> POLISHED_GRANITE_BELL = block(MinatoFurnitureModBlocks.POLISHED_GRANITE_BELL);
	public static final DeferredHolder<Item, Item> POLISHED_DIORITE_BELL = block(MinatoFurnitureModBlocks.POLISHED_DIORITE_BELL);
	public static final DeferredHolder<Item, Item> POLISHED_ANDESITE_BELL = block(MinatoFurnitureModBlocks.POLISHED_ANDESITE_BELL);
	public static final DeferredHolder<Item, Item> CHERRY_BELL = block(MinatoFurnitureModBlocks.CHERRY_BELL);
	public static final DeferredHolder<Item, Item> MANGROVE_BELL = block(MinatoFurnitureModBlocks.MANGROVE_BELL);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
