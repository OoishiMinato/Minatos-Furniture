
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.minatosfurniture.world.inventory.Refrigerator2GUIMenu;
import net.mcreator.minatosfurniture.world.inventory.Refrigerator1GUIMenu;
import net.mcreator.minatosfurniture.world.inventory.OvenMenu;
import net.mcreator.minatosfurniture.MinatoFurnitureMod;

public class MinatoFurnitureModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, MinatoFurnitureMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<Refrigerator2GUIMenu>> REFRIGERATOR_2_GUI = REGISTRY.register("refrigerator_2_gui", () -> IMenuTypeExtension.create(Refrigerator2GUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Refrigerator1GUIMenu>> REFRIGERATOR_1_GUI = REGISTRY.register("refrigerator_1_gui", () -> IMenuTypeExtension.create(Refrigerator1GUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<OvenMenu>> OVEN = REGISTRY.register("oven", () -> IMenuTypeExtension.create(OvenMenu::new));
}
