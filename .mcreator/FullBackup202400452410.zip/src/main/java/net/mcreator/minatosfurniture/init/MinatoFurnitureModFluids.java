
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.minatosfurniture.fluid.HotSpringFluid;
import net.mcreator.minatosfurniture.MinatoFurnitureMod;

public class MinatoFurnitureModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, MinatoFurnitureMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> HOT_SPRING = REGISTRY.register("hot_spring", () -> new HotSpringFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_HOT_SPRING = REGISTRY.register("flowing_hot_spring", () -> new HotSpringFluid.Flowing());

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(HOT_SPRING.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_HOT_SPRING.get(), RenderType.translucent());
		}
	}
}
