
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.minatosfurniture.potion.CoolMobEffect;
import net.mcreator.minatosfurniture.MinatoFurnitureMod;

public class MinatoFurnitureModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, MinatoFurnitureMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> COOL = REGISTRY.register("cool", () -> new CoolMobEffect());
}
