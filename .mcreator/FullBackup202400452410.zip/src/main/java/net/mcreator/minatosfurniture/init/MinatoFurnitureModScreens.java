
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.minatosfurniture.client.gui.Refrigerator2GUIScreen;
import net.mcreator.minatosfurniture.client.gui.Refrigerator1GUIScreen;
import net.mcreator.minatosfurniture.client.gui.OvenScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MinatoFurnitureModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(MinatoFurnitureModMenus.REFRIGERATOR_2_GUI.get(), Refrigerator2GUIScreen::new);
		event.register(MinatoFurnitureModMenus.REFRIGERATOR_1_GUI.get(), Refrigerator1GUIScreen::new);
		event.register(MinatoFurnitureModMenus.OVEN.get(), OvenScreen::new);
	}
}
