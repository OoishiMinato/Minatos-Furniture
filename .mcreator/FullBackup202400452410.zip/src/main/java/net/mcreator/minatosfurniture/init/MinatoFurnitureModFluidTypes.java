
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.minatosfurniture.fluid.types.HotSpringFluidType;
import net.mcreator.minatosfurniture.MinatoFurnitureMod;

public class MinatoFurnitureModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, MinatoFurnitureMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> HOT_SPRING_TYPE = REGISTRY.register("hot_spring", () -> new HotSpringFluidType());
}
