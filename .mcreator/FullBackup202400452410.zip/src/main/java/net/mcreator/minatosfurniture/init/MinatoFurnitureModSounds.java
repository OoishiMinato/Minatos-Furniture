
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minatosfurniture.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.minatosfurniture.MinatoFurnitureMod;

public class MinatoFurnitureModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, MinatoFurnitureMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> DERU = REGISTRY.register("deru", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("minato_furniture", "deru")));
	public static final DeferredHolder<SoundEvent, SoundEvent> IRERU = REGISTRY.register("ireru", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("minato_furniture", "ireru")));
	public static final DeferredHolder<SoundEvent, SoundEvent> KEZURU = REGISTRY.register("kezuru", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("minato_furniture", "kezuru")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SENPUKI = REGISTRY.register("senpuki", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("minato_furniture", "senpuki")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FLUSH = REGISTRY.register("flush", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("minato_furniture", "flush")));
	public static final DeferredHolder<SoundEvent, SoundEvent> BELL = REGISTRY.register("bell", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("minato_furniture", "bell")));
}
